module CodeCLI where

import Types
import System.IO

doesQuit :: Char -> Bool
doesQuit 'q' = True
doesQuit _ = False

promptLine :: String -> IO String
promptLine prompt = do
    putStr prompt
    getLine



lettering :: Char -> Picture
lettering s f x y 
    | x == 0 && y == 0 = s
    | otherwise = f x y

translated :: Integer -> Integer -> Picture -> Picture
translated x y pic f a b = pic (translatedAll (-x) (-y) f ) (a - x) (b - y)

translatedAll :: Integer -> Integer -> DrawFun ->DrawFun
translatedAll x y f a b = f (a - x) (b - y)


blankDraw :: DrawFun
blankDraw _ _ = ' '

printPic :: Picture -> IO ()
printPic pic  =  mapM_ putStrLn [[(pic  blankDraw) x (-y) | x <- [-20..20]] | y <- [-20..20]]

activityOf :: world -> (Event -> world -> world) -> (world -> Picture) -> IO ()
activityOf state0 handle draw = do 
    hSetBuffering stdin NoBuffering
    putStr "\ESCc" 
    putStr "\ESC?25l"
    printPic (draw state0) 
    input <- getChar
    let state' = handle (KeyPress [input]) state0
    if doesQuit input
     then return ()
     else 
        activityOf state' handle draw 
            
     

    
-- activityOf state0 handle draw = loop state0 where
--     loop state = do
--         let picture = draw state
--         clearScreen
--         display picture
--         event <- getKey
--         let state' = handle event state
--         loop state'