# sokoban
sokoban game implemented in haskell

using a codeworld-api package

to run the project & install the dependencies install cabal and run cabal update; cabal run; inside the project's main dir
